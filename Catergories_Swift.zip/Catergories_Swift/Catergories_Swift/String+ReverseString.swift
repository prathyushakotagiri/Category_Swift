//
//  String+ReverseString.swift
//  Catergories_Swift
//
//  Created by Prathyusha kotagiri on 10/23/15.
//  Copyright (c) 2015 Prathyusha kotagiri. All rights reserved.
//

import Foundation

    extension String{
    
        func reverseOfAString(setValue:String) -> String
        {
            var strReverse:String = String()
            
            var icount:Int = 0
            
            for(icount = setValue.characters.count-1; icount >= 0 ; icount -= 1){
                
                let array = Array(setValue.characters)[icount]
            
                strReverse.append(array)
            }
            
            return strReverse
        }
    }