//
//  ArrayReverse.swift
//  Catergories_Swift
//
//  Created by Prathyusha kotagiri on 5/6/16.
//  Copyright © 2016 Prathyusha kotagiri. All rights reserved.
//

import Foundation

extension NSArray{
    
    func reverseArray(orgArray:NSArray) -> NSArray {
        
        let tempAry:NSMutableArray = NSMutableArray()
        
        var iValue = orgArray.count - 1
        
        for(iValue = orgArray.count - 1; iValue>=0; iValue -= 1){
            
            tempAry.addObject(iValue)
            
        }
        return tempAry
    }
    
    
}
