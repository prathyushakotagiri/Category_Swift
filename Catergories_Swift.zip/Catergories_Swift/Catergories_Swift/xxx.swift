//
//  xxx.swift
//  Catergories_Swift
//
//  Created by Prathyusha kotagiri on 6/21/16.
//  Copyright © 2016 Prathyusha kotagiri. All rights reserved.
//

import Foundation

extension NSArray{
    
    func  xxx(ivalue:Int) -> Int {
        
        return ivalue
    }
    
}
