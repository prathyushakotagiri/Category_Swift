//
//  ViewController.swift
//  Catergories_Swift
//
//  Created by Prathyusha kotagiri on 10/23/15.
//  Copyright (c) 2015 Prathyusha kotagiri. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //iOS - Source - Swift File
        
        //To create Categories an empty swift file then use extension 
        
        var sampleString:String = String()
        sampleString = sampleString.reverseOfAString("IOS Platform")
        
        print("\(sampleString)")
        
        let normalArray:NSArray = NSArray(objects: "1","2","3","4")
        
        print("\(normalArray.reverseArray(normalArray))")
        
        print(normalArray.xxx(5))
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

